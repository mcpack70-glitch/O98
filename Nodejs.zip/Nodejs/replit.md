# Bizim Chat

## Overview

Bizim Chat is a real-time chat application built with Node.js, Express, and Socket.IO. It provides a simple, WhatsApp-style chat interface where multiple users can send and receive messages in real-time through WebSocket connections.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Express.js serves as the HTTP server foundation
- **Real-time Communication**: Socket.IO handles bidirectional WebSocket connections between clients and server
- **Server Entry Point**: `server.js` is the main application file (also referenced by `index.js`)
- **Static File Serving**: Express static middleware serves the frontend from the `public/` directory

### Frontend Architecture
- **Single Page Application**: Simple HTML/CSS/JavaScript chat interface in `public/index.html`
- **Styling**: Inline CSS with WhatsApp-inspired green theme (#075e54, #dcf8c6)
- **Socket.IO Client**: Uses the Socket.IO client library served automatically by the server

### Real-time Messaging Pattern
- **Event-based**: Uses Socket.IO events for message broadcasting
- **Broadcast Model**: When a client sends a "chat" event, the server broadcasts it to all connected clients via `io.emit()`
- **Connection Tracking**: Server logs user connections and disconnections

### Project Structure
```
├── index.js          # Entry point (requires server.js)
├── server.js         # Main Express + Socket.IO server
├── package.json      # Dependencies and scripts
└── public/
    └── index.html    # Chat interface (HTML/CSS/JS)
```

## External Dependencies

### NPM Packages
- **express (^4.18.2)**: Web server framework for HTTP handling and static file serving
- **socket.io (^4.7.2)**: Real-time bidirectional event-based communication

### Runtime Configuration
- **Port**: Configurable via `PORT` environment variable, defaults to 5000
- **Host**: Binds to `0.0.0.0` for external accessibility

### No Database
- Currently no persistent storage - messages exist only in memory during active sessions
- No user authentication system in place